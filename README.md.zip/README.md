# XIOXIO - Catálogo de Productos para el Invierno

## Descripción
XIOXIO es una aplicación web que muestra un catálogo de productos para la temporada de invierno. Los usuarios pueden explorar diferentes categorías de productos como abrigos, botas, accesorios y suéteres, ver detalles de cada producto y filtrar por categoría.

## Características
- Catálogo de productos con imágenes, nombres y precios
- Filtrado de productos por categoría
- Vista detallada de cada producto mediante un modal
- Diseño responsivo para diferentes tamaños de pantalla
- Animaciones y transiciones para mejorar la experiencia de usuario
- Simulación de carga de datos desde una API

## Tecnologías utilizadas
- HTML5
- CSS3 (con animaciones y media queries)
- JavaScript (ES6+)
- Bootstrap 5
- Fetch API

## Estructura del proyecto