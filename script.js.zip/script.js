// Elementos del DOM
const productosContainer = document.getElementById('productos');
const loadingIndicator = document.getElementById('loading');
const categoriaFiltro = document.getElementById('categoriaFiltro');
const modal = new bootstrap.Modal(document.getElementById('productoModal'));
const modalNombre = document.getElementById('modalNombre');
const modalPrecio = document.getElementById('modalPrecio');
const modalDescripcion = document.getElementById('modalDescripcion');
const modalImagen = document.getElementById('modalImagen');

// Array para almacenar todos los productos
let todosLosProductos = [];

// Función para cargar los productos desde la API
async function cargarProductos() {
    try {
        // Simulamos una llamada a una API con un retraso
        const response = await fetch('https://fakestoreapi.com/products');
        const data = await response.json();
        
        // Transformamos los datos para adaptarlos a nuestro catálogo de invierno
        todosLosProductos = data.slice(0, 10).map((item, index) => {
            const categorias = ['abrigos', 'botas', 'accesorios', 'sueteres'];
            const categoria = categorias[index % categorias.length];
            
            return {
                id: item.id,
                nombre: adaptarNombreProducto(item.title, categoria),
                precio: item.price,
                imagen: item.image,
                descripcion: `${item.description.substring(0, 150)}... Perfecto para el invierno, este producto te mantendrá abrigado y con estilo durante la temporada fría.`,
                categoria: categoria
            };
        });
        
        // Ocultar indicador de carga
        loadingIndicator.style.display = 'none';
        
        // Mostrar los productos
        mostrarProductos(todosLosProductos);
    } catch (error) {
        console.error('Error al cargar los productos:', error);
        loadingIndicator.innerHTML = '<p class="text-danger">Error al cargar los productos. Por favor, intenta de nuevo más tarde.</p>';
    }
}

// Función para adaptar los nombres de productos a productos de invierno
function adaptarNombreProducto(titulo, categoria) {
    const prefijos = {
        'abrigos': 'Abrigo de invierno',
        'botas': 'Botas de nieve',
        'accesorios': 'Accesorio invernal',
        'sueteres': 'Suéter de lana'
    };
    
    return `${prefijos[categoria]} ${titulo.split(' ').slice(0, 2).join(' ')}`;
}

// Función para mostrar los productos en el DOM
function mostrarProductos(productos) {
    productosContainer.innerHTML = '';
    
    if (productos.length === 0) {
        productosContainer.innerHTML = '<div class="col-12 text-center"><p>No se encontraron productos en esta categoría.</p></div>';
        return;
    }
    
    productos.forEach((producto, index) => {
        // Añadir un retraso escalonado para la animación
        const delay = index * 0.1;
        
        const productoHTML = `
            <div class="col-md-6 col-lg-4 producto-item" style="animation-delay: ${delay}s">
                <div class="card h-100">
                    <img src="${producto.imagen}" class="card-img-top" alt="${producto.nombre}">
                    <div class="card-body d-flex flex-column">
                        <h5 class="card-title">${producto.nombre}</h5>
                        <p class="card-text text-primary fw-bold">$${producto.precio.toFixed(2)}</p>
                        <button class="btn btn-outline-primary mt-auto btn-ver-mas" 
                                data-id="${producto.id}">Ver más</button>
                    </div>
                </div>
            </div>
        `;
        
        productosContainer.innerHTML += productoHTML;
    });
    
    // Añadir event listeners a los botones "Ver más"
    document.querySelectorAll('.btn-ver-mas').forEach(boton => {
        boton.addEventListener('click', mostrarDetallesProducto);
    });
}

// Función para mostrar los detalles del producto en el modal
function mostrarDetallesProducto(event) {
    const productoId = parseInt(event.target.dataset.id);
    const producto = todosLosProductos.find(p => p.id === productoId);
    
    if (producto) {
        modalNombre.textContent = producto.nombre;
        modalPrecio.textContent = `$${producto.precio.toFixed(2)}`;
        modalDescripcion.textContent = producto.descripcion;
        modalImagen.src = producto.imagen;
        modalImagen.alt = producto.nombre;
        
        modal.show();
    }
}

// Función para filtrar productos por categoría
function filtrarProductos() {
    const categoriaSeleccionada = categoriaFiltro.value;
    
    if (categoriaSeleccionada === 'todos') {
        mostrarProductos(todosLosProductos);
    } else {
        const productosFiltrados = todosLosProductos.filter(
            producto => producto.categoria === categoriaSeleccionada
        );
        mostrarProductos(productosFiltrados);
    }
}

// Event listeners
categoriaFiltro.addEventListener('change', filtrarProductos);

// Iniciar la aplicación
document.addEventListener('DOMContentLoaded', cargarProductos);